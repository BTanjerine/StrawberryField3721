import sys
from unittest.mock import call

# TODO: better tests


def test_precise_delay(wpimock):

    from robotpy_ext.misc import PreciseDelay

    # delay = PreciseDelay(1)

    # Make sure the wait executes twice
    # delay.timer.hasPeriodPassed.side_effect = [False, True]
    # delay.wait()

    # delay.timer.hasPeriodPassed.assert_has_calls([call(1), call(1)])
    pass
